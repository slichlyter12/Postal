<?php include("_header.php");

?>

    <div class="container">
        <div class="jumbotron">
			<h1 style="text-align: center;">World War One Database</h1>
		</div>
	</div>
    <!--Links to each of the pages with queries, db update pages are hidden -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-offset-3 col-lg-6">
                <h3 style="text-align: center;">Click a section button to learn about different WW1 Topics.</h3>
                <div style="margin-top: 5%;">
                    <div style="display:inline-block;margin: auto;;width:25%;"><a class="btn btn-primary btn-larger center-block" href="entente.php" role="button">Triple Entente</a></div>
                    <div style="display:inline-block;margin: auto;width:25%;"><a class="btn btn-primary btn-larger center-block" href="central.php" role="button">Central Powers</a></div>
                    <div style="display:inline-block;margin: auto;width:25%;"><a class="btn btn-primary btn-larger center-block" href="battles.php" role="button">Battles List</a></div>
                    <div style="display:inline-block;margin: auto;;width:23%;"><a class="btn btn-primary btn-larger center-block" href="tables.php" role="button">Database Tables</a></div>
                </div>
            </div>
        </div>
    

    </div>





    </body>
</html>